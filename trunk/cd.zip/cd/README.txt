Zawarto�� folder�w:

�	Umieszczony w katalogu �SRC� gotowy do zbudowania w �rodowisku programistycznym Microsoft Visual Studio 2008 projekt. Zawiera on kody �r�d�owe oraz pliki niezb�dne do uruchomienia programu (przyk�adowe konfiguracje oraz biblioteki do��czane dynamicznie) w katalogu �RunEnv�.
�	W katalogu �EXE� skompilowana aplikacja (w wersji DVD dodatkowo nagrane wcze�niej przyk�adowe filmy wej�ciowe), oraz plikami mapa.graph dla I pi�tra budynku C3 Akademii G�rniczo-Hutniczej w Krakowie, plikami z markerami w formacie biblioteki ARToolKit, przyk�adowym plikiem konfiguracyjnym kamery (WDM_camera.xml) oraz plikiem �markery.pdf� zawieraj�cym gotowe do wydrukowania markery, kt�rych u�ywali�my przy testowaniu aplikacji (umieszczone w folderze �Data�).
�	W katalogu �UTLS� program �mk_patt� z biblioteki ARToolKit s�u��cy do zapisywania marker�w w formacie umo�liwiaj�cym ich wykorzystanie w programie.
�	W katalogu �DOC� raport w formatach PDF oraz DOCX.
